const completedItems = require('../persistence/completedItems');

module.exports = async (req, res, next) => {
    try {
        const items = await completedItems.getItems();
        res.send(items);
    } catch (err) {
        next(err);
    }
};
