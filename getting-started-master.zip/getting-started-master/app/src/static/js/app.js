// Vibe Coder: Rick Sharer Sep 2026
//
const backgroundImages = [
    "linear-gradient(rgba(10, 20, 31, 0.28), rgba(10, 20, 30, 0.28)), url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(8, 19, 31, 0.26), rgba(8, 19, 31, 0.26)), url('https://images.unsplash.com/photo-1493558103817-58b2924bce98?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(7, 15, 28, 0.3), rgba(7, 15, 28, 0.3)), url('https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(255, 255, 255, 0.28), rgba(255, 255, 255, 0.28)), url('https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(10, 16, 28, 0.42), rgba(10, 16, 28, 0.42)), url('https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(15, 23, 42, 0.35), rgba(15, 23, 42, 0.35)), url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(14, 17, 22, 0.45), rgba(14, 17, 22, 0.45)), url('https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(32, 41, 43, 0.38), rgba(32, 41, 43, 0.38)), url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(17, 24, 39, 0.36), rgba(17, 24, 39, 0.36)), url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(20, 28, 38, 0.45), rgba(20, 28, 38, 0.45)), url('https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(11, 17, 26, 0.42), rgba(11, 17, 26, 0.42)), url('https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(52, 35, 16, 0.38), rgba(52, 35, 16, 0.38)), url('https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(17, 18, 30, 0.42), rgba(17, 18, 30, 0.42)), url('https://images.unsplash.com/photo-1493246318656-5bfd4cfb29b8?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(8, 15, 35, 0.38), rgba(8, 15, 35, 0.38)), url('https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(10, 18, 42, 0.42), rgba(10, 18, 42, 0.42)), url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(18, 12, 35, 0.38), rgba(18, 12, 35, 0.38)), url('https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(20, 10, 32, 0.4), rgba(20, 10, 32, 0.4)), url('https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(12, 16, 38, 0.4), rgba(12, 16, 38, 0.4)), url('https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(14, 20, 45, 0.4), rgba(14, 20, 45, 0.4)), url('https://images.unsplash.com/photo-1516339901601-2e1b62dc0c45?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(14, 35, 42, 0.32), rgba(14, 35, 42, 0.32)), url('https://images.unsplash.com/photo-1439853949127-fa647821eba0?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(18, 35, 38, 0.34), rgba(18, 35, 38, 0.34)), url('https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(12, 30, 45, 0.34), rgba(12, 30, 45, 0.34)), url('https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(22, 38, 42, 0.32), rgba(22, 38, 42, 0.32)), url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(16, 34, 40, 0.34), rgba(16, 34, 40, 0.34)), url('https://images.unsplash.com/photo-1464278533981-50106e6176b1?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(74, 45, 20, 0.32), rgba(74, 45, 20, 0.32)), url('https://images.unsplash.com/photo-1509316785289-025f5b846b35?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(82, 48, 22, 0.3), rgba(155, 123, 99, 0.3)), url('https://images.unsplash.com/photo-1473580044384-7ba9967e16a0?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(14, 24, 38, 0.42), rgba(14, 24, 38, 0.42)), url('https://images.unsplash.com/photo-1482192596544-9eb780fc7f66?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(18, 28, 38, 0.5), rgba(18, 28, 38, 0.5)), url('https://images.unsplash.com/photo-1482192596544-9eb780fc7f66?auto=format&fit=crop&w=2400&q=85')",
    "linear-gradient(rgba(17, 25, 35, 0.5), rgba(17, 25, 35, 0.5)), url('https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&w=2400&q=85')",
    "linear-gradient(rgba(28, 24, 18, 0.38), rgba(28, 24, 18, 0.38)), url('https://images.unsplash.com/photo-1521295121783-8a321d551ad2?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(17, 19, 35, 0.42), rgba(17, 19, 35, 0.42)), url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(255, 136, 72, 0.26), rgba(255, 136, 72, 0.26)), url('https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=2000&q=85')",
    "linear-gradient(rgba(255, 121, 68, 0.24), rgba(255, 121, 68, 0.24)), url('https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=2000&q=85')",
];

function App() {
    const { Container, Row, Col, Button } = ReactBootstrap;
    const [showNotes, setShowNotes] = React.useState(
        () => window.localStorage.getItem('todo-show-notes') !== 'false',
    );
    const [showCompletedItems, setShowCompletedItems] = React.useState(false);
    const [completedItems, setCompletedItems] = React.useState(null);
    const [completedItemsLoading, setCompletedItemsLoading] =
        React.useState(false);
    const [completedItemsError, setCompletedItemsError] = React.useState(null);

    const toggleNotes = () => {
        setShowNotes((currentValue) => {
            const nextValue = !currentValue;
            window.localStorage.setItem('todo-show-notes', nextValue);
            return nextValue;
        });
    };

    const toggleCompletedItems = async () => {
        if (showCompletedItems) {
            setShowCompletedItems(false);
            return;
        }

        setShowCompletedItems(true);
        setCompletedItemsLoading(true);
        setCompletedItemsError(null);

        try {
            const response = await fetch('/completed-items');
            if (!response.ok) {
                throw new Error(
                    `Unable to load completed items (${response.status})`,
                );
            }
            setCompletedItems(await response.json());
        } catch (error) {
            setCompletedItemsError(error.message);
        } finally {
            setCompletedItemsLoading(false);
        }
    };

    React.useEffect(() => {
        let remainingIndexes = [...backgroundImages.keys()];
        let currentIndex = -1;
        const body = document.body;

        const selectNextIndex = () => {
            if (remainingIndexes.length === 0) {
                remainingIndexes = [...backgroundImages.keys()];
            }

            const randomIndex = Math.floor(
                Math.random() * remainingIndexes.length,
            );
            currentIndex = remainingIndexes[randomIndex];
            remainingIndexes.splice(randomIndex, 1);
            return currentIndex;
        };

        const nextIndex = selectNextIndex();
        body.style.setProperty(
            '--background-image',
            backgroundImages[nextIndex],
        );

        const intervalId = setInterval(() => {
            const nextBackgroundIndex = selectNextIndex();
            body.style.setProperty(
                '--next-background-image',
                backgroundImages[nextBackgroundIndex],
            );
            body.classList.add('background-fading');

            window.setTimeout(() => {
                body.style.setProperty(
                    '--background-image',
                    backgroundImages[nextBackgroundIndex],
                );
                body.classList.remove('background-fading');
            }, 1400);
        }, 30 * 1000);

        return () => clearInterval(intervalId);
    }, []);

    return (
        <Container>
            <div className="notes-toggle-container">
                <Button
                    type="button"
                    variant="light"
                    className="notes-toggle"
                    onClick={toggleNotes}
                    aria-pressed={showNotes}
                >
                    {showNotes ? 'Hide Images' : 'Show Images'}
                </Button>
                <Button
                    type="button"
                    variant="light"
                    className="notes-toggle completed-items-toggle"
                    onClick={toggleCompletedItems}
                    aria-expanded={showCompletedItems}
                    aria-controls="completed-items-panel"
                >
                    {completedItemsLoading
                        ? 'Loading Completed Items...'
                        : showCompletedItems
                          ? 'Hide Completed Items'
                          : 'Show Completed Items'}
                </Button>
            </div>
            {showCompletedItems && (
                <section
                    id="completed-items-panel"
                    className="completed-items-panel"
                    aria-label="Archived completed items"
                >
                    <h2>Completed Items</h2>
                    {completedItemsLoading ? (
                        <p>Loading archived items...</p>
                    ) : completedItemsError ? (
                        <p role="alert">{completedItemsError}</p>
                    ) : completedItems && completedItems.length ? (
                        <ul>
                            {completedItems.map((item, index) => (
                                <li key={`${item.id}-${index}`}>{item.name}</li>
                            ))}
                        </ul>
                    ) : (
                        <p>No archived completed items.</p>
                    )}
                </section>
            )}
            <Row>
                {showNotes && (
                    <Col md={3}>
                        <ScreenshotNote />
                    </Col>
                )}
                <Col md={{ offset: 3, span: 6 }}>
                    <h1 className="todo-title">
                        Spyder{' '}
                        <span className="todo-title-highlight">To Do</span> List
                    </h1>
                    <TodoListCard />
                </Col>
            </Row>
        </Container>
    );
}

function ScreenshotNote() {
    const [screenshots, setScreenshots] = React.useState(() => {
        const savedScreenshots = window.localStorage.getItem(
            'todo-pinned-screenshots',
        );
        const legacyScreenshot = window.localStorage.getItem(
            'todo-pinned-screenshot',
        );

        if (savedScreenshots) {
            try {
                return JSON.parse(savedScreenshots);
            } catch (error) {
                return [];
            }
        }

        return legacyScreenshot ? [legacyScreenshot] : [];
    });

    const addScreenshots = (files) => {
        const readers = Array.from(files).map(
            (file) =>
                new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.readAsDataURL(file);
                }),
        );

        Promise.all(readers).then((images) => {
            setScreenshots((currentScreenshots) => {
                const nextScreenshots = [...currentScreenshots, ...images];
                window.localStorage.setItem(
                    'todo-pinned-screenshots',
                    JSON.stringify(nextScreenshots),
                );
                return nextScreenshots;
            });
        });
    };

    const pinScreenshots = (event) => {
        addScreenshots(event.target.files);
        event.target.value = '';
    };

    const pasteScreenshots = (event) => {
        const imageFiles = Array.from(event.clipboardData.items)
            .filter((item) => item.type.startsWith('image/'))
            .map((item) => item.getAsFile())
            .filter(Boolean);

        if (!imageFiles.length) return;

        event.preventDefault();
        addScreenshots(imageFiles);
    };

    const removeScreenshot = (indexToRemove) => {
        setScreenshots((currentScreenshots) => {
            const nextScreenshots = currentScreenshots.filter(
                (_, index) => index !== indexToRemove,
            );
            window.localStorage.setItem(
                'todo-pinned-screenshots',
                JSON.stringify(nextScreenshots),
            );
            return nextScreenshots;
        });
    };

    return (
        <aside
            className="notes-panel"
            aria-label="Notes"
            onPaste={pasteScreenshots}
            tabIndex={0}
        >
            <div className="notes-heading">
                <span>IMAGES</span>
                <i className="fas fa-thumbtack" aria-hidden="true" />
            </div>
            {screenshots.length ? (
                screenshots.map((screenshot, index) => (
                    <div className="pinned-screenshot" key={screenshot + index}>
                        <img src={screenshot} alt="Pinned screenshot" />
                        <button
                            type="button"
                            className="remove-screenshot"
                            onClick={() => removeScreenshot(index)}
                            aria-label="Remove pinned screenshot"
                            title="Remove pinned screenshot"
                        >
                            <i className="fas fa-times" aria-hidden="true" />
                        </button>
                    </div>
                ))
            ) : (
                <p className="notes-empty">
                    Click here and paste images, or pin screenshots for quick
                    reference.
                </p>
            )}
            <label className="pin-screenshot-button">
                <i className="fas fa-image" aria-hidden="true" />
                {screenshots.length ? 'Add screenshots' : 'Pin screenshot'}
                <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={pinScreenshots}
                />
            </label>
        </aside>
    );
}

function TodoListCard() {
    const [items, setItems] = React.useState(null);

    React.useEffect(() => {
        fetch('/items')
            .then((r) => r.json())
            .then(setItems);
    }, []);

    const onNewItem = React.useCallback(
        (newItem) => {
            setItems([...items, newItem]);
        },
        [items],
    );

    const onItemUpdate = React.useCallback(
        (item) => {
            const index = items.findIndex((i) => i.id === item.id);
            setItems([
                ...items.slice(0, index),
                item,
                ...items.slice(index + 1),
            ]);
        },
        [items],
    );

    const onItemRemoval = React.useCallback(
        (item) => {
            const index = items.findIndex((i) => i.id === item.id);
            setItems([...items.slice(0, index), ...items.slice(index + 1)]);
        },
        [items],
    );

    if (items === null) return 'Loading...';

    const orderedItems = [...items].sort(
        (firstItem, secondItem) =>
            Number(firstItem.completed) - Number(secondItem.completed),
    );

    let completedItemIndex = 0;

    return (
        <React.Fragment>
            <AddItemForm onNewItem={onNewItem} />
            {items.length === 0 && (
                <p className="text-center">
                    SPYDER! You have ZERO To Do items yet! Add one above!
                </p>
            )}
            {orderedItems.map((item) => {
                const stagger = item.completed
                    ? completedItemIndex++ % 2 === 0
                        ? 'left'
                        : 'right'
                    : null;

                return (
                    <ItemDisplay
                        item={item}
                        key={item.id}
                        onItemUpdate={onItemUpdate}
                        onItemRemoval={onItemRemoval}
                        stagger={stagger}
                    />
                );
            })}
        </React.Fragment>
    );
}

function AddItemForm({ onNewItem }) {
    const { Form, InputGroup, Button } = ReactBootstrap;

    const [newItem, setNewItem] = React.useState('');
    const [submitting, setSubmitting] = React.useState(false);

    const submitNewItem = (e) => {
        e.preventDefault();
        setSubmitting(true);
        fetch('/items', {
            method: 'POST',
            body: JSON.stringify({ name: newItem }),
            headers: { 'Content-Type': 'application/json' },
        })
            .then((r) => r.json())
            .then((item) => {
                onNewItem(item);
                setSubmitting(false);
                setNewItem('');
            });
    };

    return (
        <Form onSubmit={submitNewItem}>
            <InputGroup className="mb-3">
                <Form.Control
                    value={newItem}
                    onChange={(e) => setNewItem(e.target.value)}
                    type="text"
                    placeholder="New Item"
                    aria-describedby="basic-addon1"
                />
                <InputGroup.Append>
                    <Button
                        type="submit"
                        variant="success"
                        disabled={!newItem.length}
                        className={submitting ? 'disabled' : ''}
                    >
                        {submitting ? 'Adding...' : 'Add Item'}
                    </Button>
                </InputGroup.Append>
            </InputGroup>
        </Form>
    );
}

function ItemDisplay({ item, onItemUpdate, onItemRemoval, stagger }) {
    const { Container, Row, Col, Button, Form } = ReactBootstrap;
    const [editing, setEditing] = React.useState(false);
    const [editedName, setEditedName] = React.useState(item.name);
    const [saving, setSaving] = React.useState(false);

    const staggerStyle =
        item.completed && stagger
            ? {
                  width: '80%',
                  marginLeft: stagger === 'left' ? 0 : 'auto',
                  marginRight: stagger === 'right' ? 0 : 'auto',
              }
            : undefined;

    const toggleCompletion = () => {
        fetch(`/items/${item.id}`, {
            method: 'PUT',
            body: JSON.stringify({
                name: item.name,
                completed: !item.completed,
            }),
            headers: { 'Content-Type': 'application/json' },
        })
            .then((r) => r.json())
            .then(onItemUpdate);
    };

    const removeItem = () => {
        fetch(`/items/${item.id}`, { method: 'DELETE' }).then(() =>
            onItemRemoval(item),
        );
    };

    const startEditing = () => {
        setEditedName(item.name);
        setEditing(true);
    };

    const cancelEditing = () => {
        setEditedName(item.name);
        setEditing(false);
    };

    const saveEdit = (e) => {
        e.preventDefault();
        if (!editedName.trim()) return;

        setSaving(true);
        fetch(`/items/${item.id}`, {
            method: 'PUT',
            body: JSON.stringify({
                name: editedName.trim(),
                completed: item.completed,
            }),
            headers: { 'Content-Type': 'application/json' },
        })
            .then((r) => r.json())
            .then((updatedItem) => {
                onItemUpdate(updatedItem);
                setEditing(false);
                setSaving(false);
            });
    };

    return (
        <Container
            fluid
            className={`item ${item.completed && 'completed'} ${
                stagger ? `stagger-${stagger}` : ''
            }`}
            style={staggerStyle}
        >
            <Row>
                <Col xs={1} className="text-center">
                    <Button
                        className="toggles"
                        size="sm"
                        variant="link"
                        onClick={toggleCompletion}
                        aria-label={
                            item.completed
                                ? 'Mark item as incomplete'
                                : 'Mark item as complete'
                        }
                    >
                        <i
                            className={`far ${
                                item.completed ? 'fa-check-square' : 'fa-square'
                            }`}
                        />
                    </Button>
                </Col>
                <Col xs={9} className="name">
                    {editing ? (
                        <Form onSubmit={saveEdit}>
                            <Form.Control
                                value={editedName}
                                onChange={(e) => setEditedName(e.target.value)}
                                autoFocus
                                aria-label="Edit item"
                            />
                            <div className="mt-2">
                                <Button
                                    size="sm"
                                    variant="success"
                                    type="submit"
                                    disabled={!editedName.trim() || saving}
                                >
                                    {saving ? 'Saving...' : 'Save'}
                                </Button>{' '}
                                <Button
                                    size="sm"
                                    variant="secondary"
                                    type="button"
                                    onClick={cancelEditing}
                                    disabled={saving}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </Form>
                    ) : (
                        item.name
                    )}
                </Col>
                <Col xs={1} className="text-center edit">
                    {!editing && (
                        <Button
                            size="sm"
                            variant="link"
                            onClick={startEditing}
                            aria-label="Edit item"
                        >
                            <i className="fa fa-edit" />
                        </Button>
                    )}
                </Col>
                <Col xs={1} className="text-center remove">
                    <Button
                        size="sm"
                        variant="link"
                        onClick={removeItem}
                        aria-label="Remove Item"
                    >
                        <i className="fa fa-trash text-danger" />
                    </Button>
                </Col>
            </Row>
        </Container>
    );
}

ReactDOM.render(<App />, document.getElementById('root'));
