const fs = require('fs').promises;
const path = require('path');

const databaseLocation =
    process.env.SQLITE_DB_LOCATION || '/etc/todos/todo.db';
const location =
    process.env.COMPLETED_ITEMS_LOCATION ||
    path.join(path.dirname(databaseLocation), 'completed.json');

let writeQueue = Promise.resolve();

async function readItems() {
    try {
        const contents = await fs.readFile(location, 'utf8');
        const items = JSON.parse(contents);
        if (!Array.isArray(items)) {
            throw new Error(
                `Completed items file must contain a JSON array: ${location}`,
            );
        }
        return items;
    } catch (err) {
        if (err.code === 'ENOENT') return [];
        throw err;
    }
}

function getItems() {
    return writeQueue.then(readItems);
}

function archiveItem(item) {
    const write = writeQueue.then(async () => {
        await fs.mkdir(path.dirname(location), { recursive: true });
        const items = await readItems();
        items.push(item);

        const temporaryLocation = `${location}.${process.pid}.tmp`;
        await fs.writeFile(temporaryLocation, JSON.stringify(items, null, 2));
        await fs.rename(temporaryLocation, location);
    });

    writeQueue = write.catch(() => {});
    return write;
}

module.exports = { archiveItem, getItems };
