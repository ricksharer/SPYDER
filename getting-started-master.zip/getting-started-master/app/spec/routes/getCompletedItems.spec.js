const completedItems = require('../../src/persistence/completedItems');
const getCompletedItems = require('../../src/routes/getCompletedItems');

jest.mock('../../src/persistence/completedItems', () => ({
    getItems: jest.fn(),
}));

test('it sends archived completed items', async () => {
    const items = [{ id: '12345', name: 'Archived task', completed: false }];
    const req = {};
    const res = { send: jest.fn() };
    const next = jest.fn();
    completedItems.getItems.mockResolvedValue(items);

    await getCompletedItems(req, res, next);

    expect(res.send).toHaveBeenCalledWith(items);
    expect(next).not.toHaveBeenCalled();
});

test('it forwards archive read errors', async () => {
    const error = new Error('archive unavailable');
    const req = {};
    const res = { send: jest.fn() };
    const next = jest.fn();
    completedItems.getItems.mockRejectedValue(error);

    await getCompletedItems(req, res, next);

    expect(next).toHaveBeenCalledWith(error);
});
